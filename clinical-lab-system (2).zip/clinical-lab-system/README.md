# Clinical Laboratory Sample Tracking and Result Delivery Management System

A local academic demonstration project built with React + Vite and Node.js + Express. **It does not use a database**: application records are persisted in backend JSON files.

## Requirements
- Node.js 18 or newer (includes npm)
- Windows PowerShell

## Run on Windows
Open two PowerShell terminals.

### 1. Start backend
```powershell
cd path\to\clinical-lab-system\backend
npm install
Copy-Item .env.example .env
npm run dev
```
Backend: `http://localhost:5000`

### 2. Start frontend
```powershell
cd path\to\clinical-lab-system\frontend
npm install
npm run dev
```
Open the Vite URL shown in the terminal (normally `http://localhost:5173`).

## Demo accounts
- Admin: `admin@labtrack.test` / `Admin@12345`
- Patient: `patient@labtrack.test` / `Patient@12345`
- Patient: `priya@labtrack.test` / `Patient@12345`
- Patient: `arun@labtrack.test` / `Patient@12345`
- Patient: `meena@labtrack.test` / `Patient@12345`
- Patient: `kavin@labtrack.test` / `Patient@12345`

## Storage and reset
JSON files are in `backend/data/`. They are created/seeded on the first backend start and are not overwritten on later starts. Admins can use **Settings → Reset demo data** to restore the original demonstration dataset. Back up the `data` folder before resetting.

## Features
- Separate Admin and Patient sign-in views; server-side role checks and password hashing.
- Admin overview, patient management, test management, appointment management, sample tracking, results, report publication/delivery, notifications and settings.
- Patient profile, appointments, sample timelines, published results, PDF report downloads and notifications.
- Persistent JSON storage with serialized writes; input validation, role checks, ownership checks and centralized API errors.
- Reports are marked as illustrative DEMO DATA. Reference ranges are not for medical diagnosis.

## Important limitations
This is an educational local demo, not a production medical system. JSON files are not a substitute for a transactional database; the session secret and demo passwords must be changed before any real deployment. The app does not send email/SMS and does not diagnose or recommend treatment. Sample data and clinical values are fictional and for demonstration only.
