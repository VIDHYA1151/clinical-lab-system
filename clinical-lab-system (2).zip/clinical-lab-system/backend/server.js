require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const PDFDocument = require('pdfkit');
const { body, validationResult } = require('express-validator');
const store = require('./utils/store');
const app = express();
const PORT = process.env.PORT || 5000;
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173', credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(session({
  name: 'lab.sid', secret: process.env.SESSION_SECRET || 'local-academic-demo-change-this-secret',
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', secure: false, maxAge: 1000*60*60*4 }
}));
const now = () => new Date().toISOString();
const id = (prefix, list) => `${prefix}${1001 + list.reduce((m,x)=>Math.max(m, Number(String(x.id||'').replace(/\D/g,''))||1000),0)-1001+1}`;
const safeUser = u => ({ id:u.id, name:u.name, email:u.email, role:u.role, patientId:u.patientId, phone:u.phone, dob:u.dob, gender:u.gender, address:u.address, registrationDate:u.registrationDate });
function check(req,res,next){ if(!req.session.user) return res.status(401).json({error:'Please sign in first.'}); next(); }
function admin(req,res,next){ if(!req.session.user || req.session.user.role!=='admin') return res.status(req.session.user?403:401).json({error:'Administrator access required.'}); next(); }
function patient(req,res,next){ if(!req.session.user || req.session.user.role!=='patient') return res.status(req.session.user?403:401).json({error:'Patient access required.'}); next(); }
function validate(req,res,next){ const errors=validationResult(req); if(!errors.isEmpty()) return res.status(400).json({error:errors.array()[0].msg, details:errors.array()}); next(); }
async function notify(patientId,message,type='info'){ const n=await store.read('notifications'); n.unshift({id:`NTF${Date.now()}`,patientId,message,type,read:false,createdAt:now()}); await store.write('notifications',n); }
async function lookup(listName, key, value){ return (await store.read(listName)).find(x=>x[key]===value); }
app.get('/api/health',(req,res)=>res.json({ok:true,storage:'JSON files',database:false}));
app.post('/api/auth/login', [body('email').isEmail().withMessage('Enter a valid email.'),body('password').notEmpty().withMessage('Password is required.'),body('role').isIn(['admin','patient']).withMessage('Choose Admin or Patient.')],validate, async(req,res)=>{
  const users=await store.read('users'); const u=users.find(x=>x.email.toLowerCase()===req.body.email.toLowerCase());
  if(!u || u.role!==req.body.role || !(await bcrypt.compare(req.body.password,u.passwordHash||''))) return res.status(401).json({error:'Invalid email, password, or account type.'});
  req.session.user=safeUser(u); res.json({user:req.session.user});
});
app.get('/api/auth/me',check,(req,res)=>res.json({user:req.session.user}));
app.post('/api/auth/logout',check,(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get('/api/dashboard',check,async(req,res)=>{
 const [users,tests,appointments,samples,results]=await Promise.all(['users','tests','appointments','samples','results'].map(store.read));
 if(req.session.user.role==='admin') return res.json({totalPatients:users.filter(x=>x.role==='patient').length,totalTests:tests.length,samplesCollected:samples.filter(x=>x.status!=='Registered').length,samplesProcessing:samples.filter(x=>x.status==='Processing').length,resultsReady:results.filter(x=>x.status==='Published').length,resultsDelivered:results.filter(x=>x.deliveredAt).length});
 const pid=req.session.user.patientId, mine=a=>a.filter(x=>x.patientId===pid);
 res.json({totalAppointments:mine(appointments).length,activeSamples:mine(samples).filter(x=>!['Delivered'].includes(x.status)).length,completedTests:mine(results).length,availableReports:mine(results).filter(x=>x.status==='Published').length});
});
app.get('/api/patients',admin,async(req,res)=>res.json((await store.read('users')).filter(x=>x.role==='patient').map(safeUser)));
app.post('/api/patients',admin,[body('name').trim().notEmpty(),body('email').isEmail(),body('phone').trim().notEmpty()],validate,async(req,res)=>{
 const users=await store.read('users'); if(users.some(x=>x.email.toLowerCase()===req.body.email.toLowerCase()))return res.status(409).json({error:'Email already exists.'});
 const patientId=`PAT${Date.now().toString().slice(-6)}`; const raw={id:patientId,patientId,name:req.body.name,email:req.body.email,phone:req.body.phone,dob:req.body.dob||'',gender:req.body.gender||'',address:req.body.address||'',registrationDate:now().slice(0,10),role:'patient',passwordHash:await bcrypt.hash(req.body.password||'Patient@12345',10)};
 users.push(raw); await store.write('users',users); res.status(201).json(safeUser(raw));
});
app.put('/api/patients/:id',admin,async(req,res)=>{
 const users=await store.read('users'), i=users.findIndex(x=>x.id===req.params.id&&x.role==='patient'); if(i<0)return res.status(404).json({error:'Patient not found.'});
 if(req.body.email && users.some((x,j)=>j!==i&&x.email.toLowerCase()===req.body.email.toLowerCase()))return res.status(409).json({error:'Email already exists.'});
 for(const k of ['name','email','phone','dob','gender','address']) if(req.body[k]!==undefined) users[i][k]=req.body[k];
 await store.write('users',users); res.json(safeUser(users[i]));
});
app.delete('/api/patients/:id',admin,async(req,res)=>{
 const users=await store.read('users'), u=users.find(x=>x.id===req.params.id&&x.role==='patient'); if(!u)return res.status(404).json({error:'Patient not found.'});
 await store.write('users',users.filter(x=>x.id!==req.params.id)); res.json({ok:true});
});
app.get('/api/tests',check,async(req,res)=>res.json(await store.read('tests')));
app.post('/api/tests',admin,async(req,res)=>{const a=await store.read('tests'); if(!req.body.name)return res.status(400).json({error:'Test name is required.'}); const x={id:`TST${Date.now().toString().slice(-6)}`,name:String(req.body.name),category:req.body.category||'General',description:req.body.description||'',sampleType:req.body.sampleType||'Blood',price:Number(req.body.price)||0,processingTime:req.body.processingTime||'24 hours',available:req.body.available!==false,demo:false}; a.push(x); await store.write('tests',a);res.status(201).json(x);});
app.put('/api/tests/:id',admin,async(req,res)=>{const a=await store.read('tests'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Test not found.'});Object.assign(a[i],req.body,{id:a[i].id});await store.write('tests',a);res.json(a[i]);});
app.delete('/api/tests/:id',admin,async(req,res)=>{const a=await store.read('tests');await store.write('tests',a.filter(x=>x.id!==req.params.id));res.json({ok:true});});

app.get('/api/appointments',check,async(req,res)=>{const a=await store.read('appointments');res.json(req.session.user.role==='admin'?a:a.filter(x=>x.patientId===req.session.user.patientId));});
app.post('/api/appointments',patient,async(req,res)=>{
 const {testId,date,time}=req.body; if(!testId||!date||!time||new Date(`${date}T${time}`)<new Date())return res.status(400).json({error:'Choose a test and a valid future date and time.'});
 const test=await lookup('tests','id',testId); if(!test||!test.available)return res.status(400).json({error:'That test is not available.'});
 const a=await store.read('appointments'); const x={id:`APT${Date.now().toString().slice(-6)}`,patientId:req.session.user.patientId,testId,date,time,status:'Pending',createdAt:now(),demo:false};a.push(x);await store.write('appointments',a);await notify(x.patientId,'Your appointment request has been submitted.');res.status(201).json(x);
});
app.patch('/api/appointments/:id',check,async(req,res)=>{
 const a=await store.read('appointments'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Appointment not found.'});
 const x=a[i], isAdmin=req.session.user.role==='admin'; if(!isAdmin&&x.patientId!==req.session.user.patientId)return res.status(403).json({error:'Not your appointment.'});
 if(!isAdmin && (x.status==='Sample Collected'||x.status==='Completed'))return res.status(400).json({error:'This appointment can no longer be cancelled.'});
 if(!['Pending','Confirmed','Sample Collected','Completed','Cancelled'].includes(req.body.status))return res.status(400).json({error:'Invalid appointment status.'});
 x.status=req.body.status; if(isAdmin&&req.body.date)x.date=req.body.date;if(isAdmin&&req.body.time)x.time=req.body.time;
 await store.write('appointments',a);await notify(x.patientId,`Appointment ${x.id} status updated to ${x.status}.`);res.json(x);
});

app.get('/api/samples',check,async(req,res)=>{const a=await store.read('samples');res.json(req.session.user.role==='admin'?a:a.filter(x=>x.patientId===req.session.user.patientId));});
app.patch('/api/samples/:id',admin,async(req,res)=>{
 const a=await store.read('samples'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Sample not found.'});
 const allowed=['Registered','Sample Collected','Processing','Under Review','Results Ready','Delivered'];if(!allowed.includes(req.body.status))return res.status(400).json({error:'Invalid sample status.'});
 a[i].status=req.body.status;a[i].updatedAt=now();a[i].history=a[i].history||[];a[i].history.push({status:req.body.status,at:now()});if(req.body.status==='Sample Collected')a[i].collectionDate=now();
 await store.write('samples',a);await notify(a[i].patientId,`Sample ${a[i].id} status: ${a[i].status}.`);res.json(a[i]);
});
app.get('/api/results',check,async(req,res)=>{const a=await store.read('results');res.json(req.session.user.role==='admin'?a.filter(x=>true):a.filter(x=>x.patientId===req.session.user.patientId&&x.status==='Published'));});
app.post('/api/results',admin,async(req,res)=>{
 const {patientId,sampleId,testId,parameters}=req.body;if(!patientId||!sampleId||!testId||!Array.isArray(parameters))return res.status(400).json({error:'Patient, sample, test and parameters are required.'});
 const a=await store.read('results'),x={id:`RES${Date.now().toString().slice(-6)}`,patientId,sampleId,testId,parameters,resultDate:now().slice(0,10),interpretation:req.body.interpretation||'Illustrative demo values only.',reviewingTechnician:req.body.reviewingTechnician||'Lab Reviewer',status:'Draft',publishedAt:null,deliveredAt:null,demo:false};a.push(x);await store.write('results',a);res.status(201).json(x);
});
app.patch('/api/results/:id',admin,async(req,res)=>{
 const a=await store.read('results'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Result not found.'});
 if(req.body.status&&!['Draft','Reviewed','Published'].includes(req.body.status))return res.status(400).json({error:'Invalid result status.'});
 Object.assign(a[i],req.body,{id:a[i].id});if(req.body.status==='Published'&&!a[i].publishedAt)a[i].publishedAt=now();await store.write('results',a);
 if(req.body.status==='Published')await notify(a[i].patientId,`Your result ${a[i].id} has been published.`);res.json(a[i]);
});
app.post('/api/results/:id/deliver',admin,async(req,res)=>{const a=await store.read('results'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Result not found.'});if(a[i].status!=='Published')return res.status(400).json({error:'Publish the result before delivery.'});a[i].deliveredAt=now();await store.write('results',a);await notify(a[i].patientId,`Report ${a[i].id} marked as delivered in the portal.`);res.json(a[i]);});
app.get('/api/results/:id/pdf',check,async(req,res)=>{
 const result=await lookup('results','id',req.params.id);if(!result)return res.status(404).json({error:'Report not found.'});
 if(req.session.user.role!=='admin'&&(result.patientId!==req.session.user.patientId||result.status!=='Published'))return res.status(403).json({error:'Report is not available.'});
 const users=await store.read('users'),tests=await store.read('tests');const p=users.find(x=>x.patientId===result.patientId),t=tests.find(x=>x.id===result.testId);
 res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="${result.id}.pdf"`);
 const doc=new PDFDocument({margin:50});doc.pipe(res);doc.fontSize(20).text('Clinical Laboratory Report',{align:'center'});doc.moveDown();doc.fontSize(10).text('DEMO DATA — illustrative academic demonstration only');doc.moveDown();
 doc.fontSize(12).text(`Report ID: ${result.id}`);doc.text(`Patient: ${p?.name||result.patientId} (${result.patientId})`);doc.text(`Test: ${t?.name||result.testId}`);doc.text(`Sample ID: ${result.sampleId}`);doc.text(`Report date: ${result.resultDate}`);doc.text(`Reviewing technician: ${result.reviewingTechnician||'Not specified'}`);doc.moveDown();
 doc.fontSize(13).text('Test parameters');doc.moveDown(0.5);(result.parameters||[]).forEach(v=>doc.fontSize(10).text(`${v.name}: ${v.value} ${v.unit||''} | Reference: ${v.referenceRange||'Not specified'}`));
 doc.moveDown();doc.text(`Interpretation: ${result.interpretation||'Illustrative values only.'}`);doc.moveDown();doc.fontSize(9).text('Disclaimer: All records and values are DEMO DATA. Reference ranges are illustrative and not suitable for actual medical diagnosis. Consult a qualified healthcare professional.');doc.end();
});
app.get('/api/notifications',check,async(req,res)=>{const a=await store.read('notifications');res.json(req.session.user.role==='admin'?a:a.filter(x=>x.patientId===req.session.user.patientId));});
app.patch('/api/notifications/:id',check,async(req,res)=>{const a=await store.read('notifications'),i=a.findIndex(x=>x.id===req.params.id);if(i<0)return res.status(404).json({error:'Notification not found.'});if(req.session.user.role!=='admin'&&a[i].patientId!==req.session.user.patientId)return res.status(403).json({error:'Not your notification.'});a[i].read=true;await store.write('notifications',a);res.json(a[i]);});
app.get('/api/profile',patient,async(req,res)=>{const u=await lookup('users','patientId',req.session.user.patientId);res.json(safeUser(u));});
app.put('/api/profile',patient,async(req,res)=>{const users=await store.read('users'),i=users.findIndex(x=>x.patientId===req.session.user.patientId);for(const k of ['phone','address'])if(req.body[k]!==undefined)users[i][k]=req.body[k];await store.write('users',users);req.session.user=safeUser(users[i]);res.json(req.session.user);});
app.post('/api/settings/reset',admin,async(req,res)=>{await store.reset();const users=await store.read('users');for(const u of users){if(!u.passwordHash&&u.password){u.passwordHash=await bcrypt.hash(u.password,10);delete u.password;}}await store.write('users',users);res.json({ok:true,message:'Demo data reset. Reload the page to continue.'});});

app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Unexpected server error. Check the backend terminal.'});});
(async()=>{
 await store.initialize();
 const users=await store.read('users');
 for(const u of users) if(!u.passwordHash){u.passwordHash=await bcrypt.hash(u.password,10);delete u.password;}
 await store.write('users',users);
 app.listen(PORT,()=>console.log(`Clinical Lab API running at http://localhost:${PORT}`));
})().catch(e=>{console.error('Startup failed:',e);process.exit(1);});
