const fs = require('fs/promises');
const path = require('path');
const DATA_DIR = path.join(__dirname, '..', 'data');
const DEFAULT_DIR = path.join(__dirname, '..', 'seed');
const queues = new Map();

async function ensureDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}
async function read(name) {
  await ensureDir();
  const target = path.join(DATA_DIR, `${name}.json`);
  try { return JSON.parse(await fs.readFile(target, 'utf8')); }
  catch (e) {
    if (e.code !== 'ENOENT') throw e;
    const seedPath = path.join(DEFAULT_DIR, `${name}.json`);
    try {
      const initial = JSON.parse(await fs.readFile(seedPath, 'utf8'));
      await write(name, initial);
      return initial;
    } catch (seedError) {
      if (seedError.code === 'ENOENT') return [];
      throw seedError;
    }
  }
}
async function write(name, value) {
  await ensureDir();
  const previous = queues.get(name) || Promise.resolve();
  const current = previous.catch(() => {}).then(async () => {
    const target = path.join(DATA_DIR, `${name}.json`);
    const temp = `${target}.${process.pid}.tmp`;
    await fs.writeFile(temp, JSON.stringify(value, null, 2), 'utf8');
    await fs.rename(temp, target);
  });
  queues.set(name, current);
  await current;
}
async function reset() {
  await ensureDir();
  const names = ['users','tests','appointments','samples','results','notifications'];
  for (const name of names) {
    const source = path.join(DEFAULT_DIR, `${name}.json`);
    const value = JSON.parse(await fs.readFile(source, 'utf8'));
    await write(name, value);
  }
}
async function initialize() {
  await ensureDir();
  for (const name of ['users','tests','appointments','samples','results','notifications']) {
    const target = path.join(DATA_DIR, `${name}.json`);
    try { await fs.access(target); }
    catch { await write(name, JSON.parse(await fs.readFile(path.join(DEFAULT_DIR, `${name}.json`), 'utf8'))); }
  }
}
module.exports = { read, write, reset, initialize };
