
// Run `node --check server.js` for a syntax check. Full API checks require `npm install`.
console.log('Run: node --check server.js');
