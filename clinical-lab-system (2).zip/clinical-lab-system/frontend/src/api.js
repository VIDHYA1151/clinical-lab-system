import axios from 'axios';
const api = axios.create({baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api', withCredentials:true});
api.interceptors.response.use(r=>r,err=>{if(err.response?.status===401) window.dispatchEvent(new Event('lab-unauthorized'));return Promise.reject(err);});
export default api;
